import javax.swing.*;

public class LabelObserverButtonCommand extends ObserverCommandButton {
    public LabelObserverButtonCommand(String text, String text2, Subject primeThread, ObserverWindow window) {
        super(text, text2, primeThread, window);
    }
}
