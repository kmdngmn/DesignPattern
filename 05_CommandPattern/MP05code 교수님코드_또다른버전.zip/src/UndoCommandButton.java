import javax.swing.*;

public class UndoCommandButton extends CommandButton {
    UndoCommandButton(String text, JLabel label) {
        super(text, label);
    }
//
//    @Override
//    public void execute() {
//    }
}
