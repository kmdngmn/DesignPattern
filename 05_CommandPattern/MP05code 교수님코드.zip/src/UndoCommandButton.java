import javax.swing.*;

public class UndoCommandButton extends CommandButton {
    UndoCommandButton(String text, JLabel label) {
        super(text, label, null);
    }
//
//    @Override
//    public void execute() {
//    }
}
