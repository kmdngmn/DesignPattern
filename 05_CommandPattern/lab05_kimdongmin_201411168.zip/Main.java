public class Main {
	private static final String MAIN_TITLE = "Main Window";

	public static void main(String[] args) {
		MainWindow mainWindow = new MainWindow(MAIN_TITLE);
	}
}
