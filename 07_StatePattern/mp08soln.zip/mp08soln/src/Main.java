import java.awt.Graphics2D;

public class Main {
    public static void main(String[] a) {
        DrawShapeWindow w = new DrawShapeWindow(new MyDrawShape(), "Test", 10, 10, 300, 300);
    }
}
