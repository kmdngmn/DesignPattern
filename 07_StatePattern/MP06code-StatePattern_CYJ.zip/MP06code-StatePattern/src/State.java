public interface State {
    public void addHundred();
    public void addFiveHundred();
    public void addThousand();
    public void returnChanges();
    public void selectBeverage();
}
