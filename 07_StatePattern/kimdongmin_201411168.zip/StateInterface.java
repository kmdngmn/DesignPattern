
public interface StateInterface {

	public void insert_coin_100();

	public void insert_coin_500();

	public void insert_coin_1000();

	public void return_charges();

	public void select_beverages();

}
