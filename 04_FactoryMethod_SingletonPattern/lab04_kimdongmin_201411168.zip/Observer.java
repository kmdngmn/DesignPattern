
public interface Observer {

	public void updateText(String msg);
	
}
