
public class ByName implements ArrangeBy {

	@Override
	public void bubbleSort(FileInfo[] fileLists) {

		System.out.println("파일 이름으로 정렬된 리스트");
		for (int i = 0; i < fileLists.length - 1; i++) {
			for (int j = 0; j < fileLists.length - 1; j++) {
				if (fileLists[j].getName().compareTo(fileLists[j + 1].getName()) > 0) { // swap
					FileInfo temp = fileLists[j];
					fileLists[j] = fileLists[j + 1];
					fileLists[j + 1] = temp;
				}
			}
		}
	}

}
