
public interface ArrangeBy {

	public void bubbleSort(FileInfo[] fileLists);

}
