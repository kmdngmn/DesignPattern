public class Sorter {

	ArrangeBy arrangeBy = new ByName();

	public void setArrangeBy(ArrangeBy arrangeBy) {
		this.arrangeBy = arrangeBy;
	}

	public void bubbleSort(Object[] objs) {

		FileInfo[] fileLists = (FileInfo[]) objs;
		arrangeBy.bubbleSort(fileLists);

	}

}
