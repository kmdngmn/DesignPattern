
public class ByModifiedDate implements ArrangeBy {

	@Override
	public void bubbleSort(FileInfo[] fileLists) {

		System.out.println("파일 수정 시간으로 정렬된 리스트");
		for (int i = 0; i < fileLists.length - 1; i++) {
			for (int j = 0; j < fileLists.length - 1; j++) {
				if (fileLists[j].getModifiedDate().compareTo(fileLists[j + 1].getModifiedDate()) > 0) { // swap
					FileInfo temp = fileLists[j];
					fileLists[j] = fileLists[j + 1];
					fileLists[j + 1] = temp;
				}
			}
		}
	}

}
