
public interface Comparable {

	public int compare(Object o1, Object o2);
	
}
