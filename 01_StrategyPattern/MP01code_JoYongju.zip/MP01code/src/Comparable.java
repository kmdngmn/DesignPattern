public interface Comparable {
    public int compareTo(Object o1, Object o2);
}
